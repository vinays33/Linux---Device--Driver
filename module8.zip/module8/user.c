#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define DEVICE_PATH "/dev/Driven_class"

int main() {
    int fd;
    char read_buffer[1024];
    const char *write_buffer = "Hello from user space!";

    fd = open(DEVICE_PATH, O_RDWR);
    if (fd == -1) {
        perror("Failed to open device");
        return -1;
    }

    write(fd, write_buffer, strlen(write_buffer));
    read(fd, read_buffer, sizeof(read_buffer));
    printf("Read from device: %s\n", read_buffer);

    close(fd);
    return 0;
}
