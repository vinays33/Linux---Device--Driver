#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/device.h>
#include <linux/init.h>
#include <linux/kdev_t.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/err.h>

dev_t q = 0;
static struct cdev cfile;

static int file_open(struct inode *inode, struct file *file);
static int file_release(struct inode *inode, struct file *file);
static ssize_t file_read(struct file *flip, char __user *buf, size_t len, loff_t *off);
static ssize_t file_write(struct file *flip, const char __user *buf, size_t len, loff_t *off);

static struct file_operations fops =
    {
        .owner = THIS_MODULE,
        .read = file_read,
        .write = file_write,
        .open = file_open,
        .release = file_release};

static int file_open(struct inode *inode, struct file *file)
{
    pr_info("driver open function is called\n");
    return 0;
}

static int file_release(struct inode *inode, struct file *file)
{
    pr_info("driver release function is called\n");
    return 0;
}

static ssize_t file_read(struct file *flip, char __user *buf, size_t len, loff_t *off)
{
    pr_info("driver read function is called\n");
    return 0;
}

static ssize_t file_write(struct file *flip, const char __user *buf, size_t len, loff_t *off)
{
    pr_info("driver write function is called\n");
    return len; // Return number of bytes written, typically
}

static int __init chev_init(void)
{
    alloc_chrdev_region(&q, 0, 1, "vinay");
    pr_info("MAJOR = %d , MINOR = %d\n", MAJOR(q), MINOR(q));

    cdev_init(&cfile, &fops);
    cdev_add(&cfile, q, 1);

    pr_info("driver inserted\n");
    return 0;
}

static void __exit chev_exit(void)
{
    cdev_del(&cfile);
    unregister_chrdev_region(q, 1);
    pr_info("driver removed\n");
}

module_init(chev_init);
module_exit(chev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("VINAY_KUMAR_RATHOR");
