#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#define DEVICE_FILE "/dev/vkr"

int main() {
    int fd;
    char buffer[50];

    fd = open(DEVICE_FILE, O_RDONLY);
    if (fd == -1) {
        perror("Open failed");
        return 1;
    }

    if (read(fd, buffer, sizeof(buffer)) == -1) {
        perror("Read failed");
        close(fd);
        return 1;
    }

    printf("Data read from device: %s\n", buffer);
    close(fd);
    return 0;
}
