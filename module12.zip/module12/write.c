#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define DEVICE_FILE "/dev/vkr"

int main() {
    int fd;
    char *data = "Hello from user space!";

    fd = open(DEVICE_FILE, O_WRONLY);
    if (fd == -1) {
        perror("Open failed");
        return 1;
    }

    if (write(fd, data, strlen(data)) == -1) {
        perror("Write failed");
        close(fd);
        return 1;
    }

    printf("Data written to device\n");
    close(fd);
    return 0;
}
