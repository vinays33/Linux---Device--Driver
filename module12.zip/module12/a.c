#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/semaphore.h>
#include <linux/wait.h>
#include <linux/uaccess.h>

#define DEVICE_COUNT 2
#define BUFFER_SIZE 50

static int major;
static char buffer[DEVICE_COUNT][BUFFER_SIZE];
static struct semaphore sem;
static wait_queue_head_t wait_queues[DEVICE_COUNT];
static int data_ready[DEVICE_COUNT] = {0, 0};

static int dev_open(struct inode *inode, struct file *file) {
    int device_num = iminor(inode);
    file->private_data = (void *)device_num;
    printk(KERN_INFO "Device %d opened\n", device_num);
    return 0;
}

static int dev_release(struct inode *inode, struct file *file) {
    printk(KERN_INFO "Device %d closed\n", iminor(inode));
    return 0;
}

static ssize_t dev_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos) {
    int device_num = (int)(file->private_data);

    if (count > BUFFER_SIZE) {
        printk(KERN_ERR "Write size too large\n");
        return -EINVAL;
    }

    down(&sem);

    if (copy_from_user(buffer[device_num], buf, count)) {
        up(&sem);
        return -EFAULT;
    }

    data_ready[device_num] = 1;
    printk(KERN_INFO "Data written to device %d\n", device_num);

    wait_event_interruptible(wait_queues[device_num], data_ready[device_num] == 0);

    up(&sem);
    return count;
}

static ssize_t dev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos) {
    int device_num = (int)(file->private_data);

    down(&sem);

    if (data_ready[device_num] == 0) {
        printk(KERN_INFO "No data to read from device %d\n", device_num);
        up(&sem);
        return -EAGAIN;
    }

    if (copy_to_user(buf, buffer[device_num], count)) {
        up(&sem);
        return -EFAULT;
    }

    data_ready[device_num] = 0;
    printk(KERN_INFO "Data read from device %d\n", device_num);

    wake_up_interruptible(&wait_queues[device_num]);

    up(&sem);
    return count;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = dev_open,
    .release = dev_release,
    .read = dev_read,
    .write = dev_write,
};

static int __init dev_init(void) {
    int result;

    result = register_chrdev(0, "vkr", &fops);
    if (result < 0) {
        printk(KERN_ERR "Failed to register device\n");
        return result;
    }
    major = result;

    sema_init(&sem, 1);

    for (int i = 0; i < DEVICE_COUNT; i++) {
        init_waitqueue_head(&wait_queues[i]);
    }

    printk(KERN_INFO "Simple device driver initialized\n");
    return 0;
}

static void __exit dev_exit(void) {
    unregister_chrdev(major, "vkr");
    printk(KERN_INFO "Simple device driver removed\n");
}

module_init(dev_init);
module_exit(dev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Simple Character Device Driver for Multiple Devices");
