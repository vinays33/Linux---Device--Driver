#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include "ioctl.h"
int main()
{
    int user, fd, operands[2], result;
    fd = open("/dev/calculator", O_RDWR);
    if (fd < 0)
    {
        perror("failed to open device");
        return 1;
    }
    operands[0] = 10;
    operands[1] = 20;
    while (1)
    {
        printf("enter the choices 1)add 2)mul 3)sub 4)div");
        scanf("%d", &user);
        switch (user)
        {
        case 1:
            ioctl(fd, CMD_ADD, operands);
            result = operands[0];
        printf("adittion %d", result);

            case 2:
            ioctl(fd, CMD_MUL, operands);
            result = operands[0];
        printf("adittion %d", result);

            case 3:
            ioctl(fd, CMD_SUB, operands);
            result = operands[0];
        printf("adittion %d", result);

            case 4:
            ioctl(fd, CMD_DIV, operands);
            result = operands[0];
            printf("adittion %d", result);
            default:
            perror("invalid command");
        }
    }
    close(fd);
    return 0;
}
