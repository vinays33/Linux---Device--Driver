#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/kdev_t.h>
#include <linux/ioctl.h>

#define mem_size 1024

dev_t dev = 0;
static struct cdev my_dev;

static int __init char_driver_init(void);
static void __exit char_driver_exit(void);

static int my_open(struct ionde *inode, struct file *file);
static int my_release(struct ionde *inode, struct file *file);
static long my_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

static struct file_operations fops =
    {
        .owner = THIS_MODULE,
        .open = my_open,
        .release = my_release,
        .unlocked_ioctl = my_ioctl,
};
static int my_open(struct ionde *inode, struct file *file)
{
    pr_info("file opened");
    return 0;
}
static int my_release(struct ionde *inode, struct file *file)
{
    pr_info("file closed");
    return 0;
}
static long my_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    int operands[2] = {0};
    int result = 0;
    switch (cmd)
    {
    case CMD_ADD:
        if (copy_from_user(operands, (int __user *)arg, sizeof(operands)))
        {
            pr_err("error to copying from operansds");
            return -EFAULT;
        }
        result = operands[0] + operands[1];
        pr_info("ADDITION %d + %d = %d", operands[0], operands[1], result);
        if (copy_to_user((int __user *)arg, &result, sizeof(result)))
            ;
        {
            pr_err("error to copy operansds");
            return -EFAULT;
        }
        break;

    case CMD_MUL:
        if (copy_from_user(operands, (int __user *)arg, sizeof(operands)))
        {
            pr_err("error to copying from operansds");
            return -EFAULT;
        }
        result = operands[0] * operands[1];
        pr_info("multiplication %d x %d = %d", operands[0], operands[1], result);
        if (copy_to_user((int __user *)arg, &result, sizeof(result)))
            ;
        {
            pr_err("error to copy operansds");
            return -EFAULT;
        }
        break;

    case CMD_SUB:
        if (copy_from_user(operands, (int __user *)arg, sizeof(operands)))
        {
            pr_err("error to copying from operansds");
            return -EFAULT;
        }
        result = operands[0] - operands[1];
        pr_info("substraction %d - %d = %d", operands[0], operands[1], result);
        if (copy_to_user((int __user *)arg, &result, sizeof(result)))
            ;
        {
            pr_err("error to copy operansds");
            return -EFAULT;
        }
        break;

    case CMD_DIV:
        if (copy_from_user(operands, (int __user *)arg, sizeof(operands)))
        {
            pr_err("error to copying from operansds");
            return -EFAULT;
        }
        result = operands[0] / operands[1];
        pr_info("divison %d / %d = %d", operands[0], operands[1], result);
        if (copy_to_user((int __user *)arg, &result, sizeof(result)))
            ;
        {
            pr_err("error to copy operansds");
            return -EFAULT;
        }
        break;
    default:
        pr_err("invalid ioctl commnad");
        break;
    }
}
static int __init char_driver_init(void)
{
    if (alloc_chrdev_region(&dev, 0, 1, "calculator") > 0)
    {
        pr_err("error to alloct major number");
        return -EFAULT;
    }
    pr_info("major =%d ,minor = %d", MAJOR(dev), MINOR(dev));
    if (cdev_init(&my_dev, &fops) > 0)
    {
        pr_err("failed to to register");
    }
    cdev_add(&my_dev, dev, 1) return 0;
}
static void __exit char_driver_exit(void)
{
    cdev_del(&my_dev);
    unregister_chdev_region(dev, 1);
    pr_info("unloaded")
}
module_init(char_driver_init);
module_exit(char_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("VINAY_KUMAR_RATHOR");
MODULE_DESCRIPTION("IOCTL Calculator Module");
