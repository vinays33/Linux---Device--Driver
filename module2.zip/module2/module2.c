// MODULE 2: PROGRAM TO PASSING PARAMETERS INTO THE CONSOL USING MODULE_PARAM FUNCTION:

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>

static int intvar = 10;
static char *charvar = "MODULE_PARAMETER";

module_param(intvar, int, 0444);
module_param(charvar, charp, 0444);

static int __init module2_init(void)
{
    printk(KERN_INFO "intvar= %d charvar= %s\n", intvar, charvar);
    printk(KERN_INFO "module inserted sucessfully\n");

    return 0;
}

static void __exit module2_exit(void)
{
    printk(KERN_INFO "module removed from kernel\n");
}

module_init(module2_init);
module_exit(module2_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("VINAY_KUMAR_RATHOR");
MODULE_DESCRIPTION("UNDERSTANDING OF MODULE PARAMETER BASICS");
MODULE_VERSION("2.0");
