// MODULE 3- PROGRAM OF EXPROT_SYMBOL IN MODULE
// MAIN FILE:

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

int add(int a, int b)
{
    return a + b;
}

EXPORT_SYMBOL(add); // export_symbol function

static int __init mod_init(void)
{
    printk(KERN_INFO "module inserted successfully\n");
    return 0;
}

static void __exit mod_exit(void)
{
    printk(KERN_INFO "module removed from kernel\n");
}

module_init(mod_init);
module_exit(mod_exit);
MODULE_LICENSE("GPL ");
MODULE_AUTHOR("VINAY_KUMAR_RATHOR");
MODULE_DESCRIPTION("UNDERSTANDING OF EXPORT SYMBOL IN MODULE");