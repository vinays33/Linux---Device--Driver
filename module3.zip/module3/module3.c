#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include "mod.h" // our add  calling function inside this library or .h file


static int a = 20;
static int b = 30;

static int __init main_module_init(void)
{
    int result = add(a, b);
    printk(KERN_INFO " values:  a = %d, b = %d, result = %d\n", a, b, result);
        printk(KERN_INFO "module inserted successfully\n");

    return 0;
}

static void __exit main_module_exit(void)
{
    printk(KERN_INFO "module removed from kernel\n");
}

module_init(main_module_init);
module_exit(main_module_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("vinay");
MODULE_DESCRIPTION("try exporting_symbol");
