// MODULE 5: PROGRAM TO ALLOCATE DYNAMICALLY DEVICE NUMBERS:

#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/types.h>
#include <linux/kdev_t.h>

dev_t dev = 0;

static int __init static_init(void)
{
    alloc_chrdev_region(&dev, 0, 1, "DYNAMIC_ALLOCATION");

    printk(KERN_INFO "Major number = %d, Minor number = %d\n", MAJOR(dev), MINOR(dev));
    printk(KERN_INFO "Module inserted successfully\n");
    return 0;
}

static void __exit static_exit(void)
{
    unregister_chrdev_region(dev, 1);
    printk(KERN_INFO "Module removed from kernel\n");
}

module_init(static_init);
module_exit(static_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("VINAY_KUMAR_RATHOR");
MODULE_DESCRIPTION("DYNAMIC ALLOCATION OF DEVICE NUMBERS");
