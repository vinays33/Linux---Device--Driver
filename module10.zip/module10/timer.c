#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/timer.h>
#include <linux/jiffies.h>

static struct timer_list my_timer;

void timer_callback(struct timer_list *t)
{
    pr_info("Timer expired at jiffies: %ld\n", jiffies);
}

static int __init my_module_init(void)
{
    pr_info("Module loaded\n");

    timer_setup(&my_timer, timer_callback, 0);

    mod_timer(&my_timer, jiffies + msecs_to_jiffies(2000));

    return 0;
}

static void __exit my_module_exit(void)
{
    pr_info("Module unloaded\n");

    del_timer(&my_timer);
}

module_init(my_module_init);
module_exit(my_module_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("VINAY_KUMAR_RATHOR");
MODULE_DESCRIPTION("A simple kernel timer module");
