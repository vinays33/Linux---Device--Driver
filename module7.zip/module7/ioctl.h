#define MAGIC_NUM 3
#define CMD_1 _IO(MAGIC_NUM, 1)
#define CMD_2 _IOR(MAGIC_NUM, 2, int)